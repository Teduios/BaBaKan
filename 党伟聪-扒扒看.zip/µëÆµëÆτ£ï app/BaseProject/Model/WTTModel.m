//
//  WTTModel.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTModel.h"

@implementation WTTModel

@end
@implementation WTTDataModel
+(NSDictionary *)objectClassInArray{
    return @{@"list":[WTTDataListModel class]};
    
}





@end




@implementation WTTDataListModel





@end
@implementation WTTDataListDisplayModel



@end

@implementation WTTDataListActionModel



@end
@implementation WTTExtModel



@end

