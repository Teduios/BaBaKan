//
//  WTTModel.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//
#import "Factory.h"
#import "BaseModel.h"

@class WTTExtModel,WTTDataModel,WTTDataListModel,WTTDataListDisplayModel,WTTDataListActionModel,WTTSHModel;
@interface WTTModel : BaseModel

@property (nonatomic, assign) BOOL status;

@property (nonatomic, strong) WTTDataModel *data;



@property (nonatomic, strong) WTTExtModel *ext;

@property (nonatomic, assign) NSInteger count;




@end


@interface WTTExtModel : BaseModel

@property (nonatomic, assign) NSInteger trending_border;

@property (nonatomic, copy) NSString *inter_url;

@property (nonatomic, assign) NSInteger c_time;

@end

@interface WTTDataModel : BaseModel

@property (nonatomic, assign) NSInteger pageno;

@property (nonatomic, assign) NSInteger currtime;

@property (nonatomic, assign) NSInteger prevtime;

@property (nonatomic, assign) NSInteger nexttime;

@property (nonatomic, strong) NSArray<WTTDataListModel *> *list;

@property (nonatomic, copy) NSString *currsign;

@property (nonatomic, copy) NSString *prevsign;

@property (nonatomic, copy) NSString *nextsign;


@end



@interface WTTDataListModel : BaseModel

@property (nonatomic, assign) BOOL is_promote;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) BOOL has_image;

@property (nonatomic, copy) NSString *summary;

@property (nonatomic, copy) NSString *ncate_id;

@property (nonatomic, copy) NSString *src_id;

@property (nonatomic, assign) NSInteger visit_num;

@property (nonatomic, assign) BOOL has_quiz;

@property (nonatomic, assign) BOOL is_trending;

@property (nonatomic, strong) WTTDataListActionModel *action;

@property (nonatomic, copy) NSString *pubtime;

@property (nonatomic, copy) NSString *img_src;

@property (nonatomic, assign) BOOL is_original;

@property (nonatomic, copy) NSString *img_position;

@property (nonatomic, copy) NSString *has_attr;

@property (nonatomic, assign) BOOL has_video;

@property (nonatomic, copy) NSString *Id;

@property (nonatomic, assign) NSInteger topic_id;

@property (nonatomic, strong) WTTDataListDisplayModel *display;

@property (nonatomic, copy) NSString *src_link;

@property (nonatomic, copy) NSString *ack_code;

@property (nonatomic, copy) NSString *src_title;

@property (nonatomic, copy) NSString *is_rec;

@property (nonatomic, copy) NSString *cate_id;


@end

@interface WTTDataListDisplayModel : BaseModel

@property (nonatomic, copy) NSString *type;

@property (nonatomic, assign) NSInteger value;

@end

@interface WTTDataListActionModel : BaseModel

@property (nonatomic, copy) NSString *target;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *value;

@end