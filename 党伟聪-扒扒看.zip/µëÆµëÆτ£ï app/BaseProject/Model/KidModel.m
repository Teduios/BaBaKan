//
//  KidModel.m
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "KidModel.h"

@implementation KidModel


+ (NSDictionary *)objectClassInArray{
    return @{@"body" : [KidBodyModel class]};
}
@end
@implementation KidMeta

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"Id":@"id"};
}

@end


@implementation KidBodyModel
+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"Id":@"id"};
}

+ (NSDictionary *)objectClassInArray{
    return @{@"img" : [kidbodyImg class]};
}
@end


@implementation KidBodyLink

@end




@implementation kidbodyImg

@end