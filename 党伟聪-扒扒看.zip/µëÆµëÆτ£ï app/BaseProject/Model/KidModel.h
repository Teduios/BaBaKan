//
//  KidModel.h
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class KidMeta,KidBodyModel,KidBodyLink,kidbodyImg,kidbodyImgSize;
@interface KidModel : BaseModel

@property (nonatomic, strong) KidMeta *meta;

@property (nonatomic, strong) NSArray<KidBodyModel *> *body;

@end
@interface KidMeta : BaseModel

@property (nonatomic, copy) NSString *Id;

@property (nonatomic, assign) NSInteger expiredTime;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, assign) NSInteger pageSize;

@end

@interface KidBodyModel : BaseModel

@property (nonatomic, copy) NSString *Id;

@property (nonatomic, copy) NSString *commentsUrl;

@property (nonatomic, assign) NSInteger comments;

@property (nonatomic, strong) KidBodyLink *link;

@property (nonatomic, assign) NSInteger likes;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger cid;

@property (nonatomic, copy) NSString *shareTitle;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *ctime;

@property (nonatomic, copy) NSString *shareUrl;

@property (nonatomic, strong) NSArray<kidbodyImg*> *img;

@property (nonatomic, copy) NSString *thumbnail;

@property (nonatomic, assign) NSInteger commentsall;

@property (nonatomic, copy) NSString *staticImg;

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *content;

@end

@interface kidbodyImg : BaseModel
@property (nonatomic,strong)NSString *url;
@property (nonatomic,strong)kidbodyImgSize *size;
@end

@interface KidBodyLink : BaseModel

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *url;

@end

