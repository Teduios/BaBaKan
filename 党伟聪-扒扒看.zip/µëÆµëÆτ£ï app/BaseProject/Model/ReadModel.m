//
//  ReadModel.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ReadModel.h"



@implementation ReadModel

+ (NSDictionary *)objectClassInArray{
    return @{@"item" : [FHItemModel class]};
}

@end


@implementation FHItemModel

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"Id":@"id"};
}

@end


@implementation FHItemLinkModel

@end




