//
//  ReadModel.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class FHItemModel,FHItemLinkModel;

//@interface ReadModel : BaseModel
//
//@property (nonatomic, strong) NSArray<FHFhesarrayModel *> *FHesArrayModel;
//
//@end

@interface ReadModel : BaseModel

@property (nonatomic, strong) NSArray<FHItemModel *> *item;

@property (nonatomic, assign) NSInteger expiredTime;

@property (nonatomic, copy) NSString *listId;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, assign) NSInteger currentPage;

@property (nonatomic, assign) NSInteger totalPage;

@end

@interface FHItemModel : BaseModel

@property (nonatomic, copy) NSString *Id;

@property (nonatomic, copy) NSString *documentId;

@property (nonatomic, copy) NSString *comments;

@property (nonatomic, strong) FHItemLinkModel *link;

@property (nonatomic, copy) NSString *source;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *commentsall;

@property (nonatomic, copy) NSString *thumbnail;

@property (nonatomic, copy) NSString *online;

@property (nonatomic, copy) NSString *commentsUrl;

@property (nonatomic, copy) NSString *updateTime;

@end

@interface FHItemLinkModel : BaseModel

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *url;

@end




