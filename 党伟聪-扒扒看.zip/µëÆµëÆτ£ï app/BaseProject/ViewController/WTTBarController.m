//
//  WTTBarController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTBarController.h"
#import "ShouYeViewController.h"

#import "PaiHangViewController.h"


#import "ContentViewController.h"
#import "VideoViewController.h"
#import "ReadViewController.h"
#import "JokeViewController.h"

@interface WTTBarController ()


@end

@implementation WTTBarController

+(WTTBarController *)standarInstance{
    static WTTBarController *vc =nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [WTTBarController new];
        
    });
    return vc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBar.translucent = NO;
   [self.navigationController setNavigationBarHidden:YES animated:YES];
   
   
    VideoViewController *vc2 = [VideoViewController new];

  
    JokeViewController *vc4 = [JokeViewController new];

    
    
    
    UINavigationController *navc1 = [ShouYeViewController standardWTTNavi];
    UINavigationController *navc2 = [[UINavigationController alloc] initWithRootViewController:vc2];
    UINavigationController *navc3 = [PaiHangViewController standarWTTPHNavi];
    

    
    
    
    UINavigationController *navc4 = [[UINavigationController alloc] initWithRootViewController:vc4];
    
    
    navc1.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"首页" image:[UIImage imageNamed:@"首页icon"] selectedImage:[UIImage imageNamed:@"首页icon-激活"]];
    // navc1.tabBarItem.imageInsets = UIEdgeInsetsMake(0, 0, 8, 0);
    navc3.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"排行" image:[UIImage imageNamed:@"排行icon"] selectedImage:[UIImage imageNamed:@"排行icon-激活"]];
    navc2.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"视频" image:[UIImage imageNamed:@"播放0"] selectedImage:[UIImage imageNamed:@"播放1"]];
    navc4.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"笑看" image:[UIImage imageNamed:@"tabbar_book_library"] selectedImage:[UIImage imageNamed:@"tabbar_book_library_hl"]];
    
    
    
    
    
    
    NSArray *controllers = [NSArray arrayWithObjects:navc1,navc2,navc3,navc4,nil];
    self.viewControllers = controllers;
    

    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
