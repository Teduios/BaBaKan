//
//  JokeViewController.h
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JokeViewModel.h"

@interface JokeViewController : UIViewController


@end
