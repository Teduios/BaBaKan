//
//  PaiHangViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PaiHangViewController.h"

#import "ContentViewController.h"





@interface PaiHangViewController ()



@end

@implementation PaiHangViewController

+(UINavigationController *)standarWTTPHNavi{
    
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        PaiHangViewController *vc= [[PaiHangViewController alloc] initWithViewControllerClasses:[self viewControllerClasses] andTheirTitles:[self itemNames]];
        
        
        vc.titleColorSelected = [UIColor redColor];
        vc.titleColorNormal = [UIColor blackColor];
        vc.menuBGColor = [UIColor lightGrayColor];
        
        vc.menuHeight = 40;
        vc.menuViewStyle = WMMenuViewStyleLine;
        vc.keys = [self vcKeys];
        vc.values = [self vcValues];
        navi = [[UINavigationController alloc] initWithRootViewController:vc];
        
        
        
    });
    
    return navi;
}



//提供每个vc对应的values值数组
+(NSArray *)vcValues{
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i < [self itemNames].count; i++) {
        //
        [arr addObject:@(i)];
    }
    return arr;
}




//提供每个VC对应的key值数组

+ (NSArray *)vcKeys{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:@"PHType"];
    }
    return [arr copy];
}

+(NSArray *)itemNames{
    return @[@"蹿红",@"周榜",@"月榜"];
}


+(NSArray *)viewControllerClasses{

    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i < [self itemNames].count; i++) {
      
     
        [arr addObject:[ContentViewController class]];
        
    }
    return [arr copy];
}




- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"排行";
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}










/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
