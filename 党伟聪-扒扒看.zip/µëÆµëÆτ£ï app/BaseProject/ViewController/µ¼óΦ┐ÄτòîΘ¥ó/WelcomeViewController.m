//
//  WelcomeViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WelcomeViewController.h"
#import "WTTBarController.h"
#import "ResideViewController.h"
#import "LoginViewController.h"


@interface WelcomeViewController ()<iCarouselDelegate,iCarouselDataSource>
//
@property(nonatomic,strong)iCarousel *ic;
//存储图片的名称


@property(nonatomic,strong)NSArray *imageNames;
//设置小圆点
@property(nonatomic,strong)UIPageControl *pageControl;


@end

@implementation WelcomeViewController

- (NSArray *)imageNames{
    NSMutableArray *arr = [NSMutableArray new];
    if (!_imageNames) {
        for (int i = 0; i < 4; i++) {
            NSString *names = [NSString stringWithFormat:@"lockscreen%d.jpg",i];
            [arr addObject:names];
        }
        
        _imageNames = [arr copy];
    }
    return _imageNames;
}


- (UIPageControl *)pageControl{
    if (!_pageControl) {
        _pageControl = [[UIPageControl alloc] initWithFrame:CGRectZero];
      
        _pageControl.numberOfPages = self.imageNames.count;
        _pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
        _pageControl.pageIndicatorTintColor = [UIColor lightGrayColor];
        
    }
    return _pageControl;
}
- (iCarousel *)ic{
    if (!_ic) {
        _ic = [iCarousel new];
        _ic.dataSource = self;
        _ic.delegate = self;
        //修改显示模式
        _ic.type = 0;
        //改为翻页模式
        _ic.pagingEnabled = NO;
        //滚动的速度
        _ic.scrollSpeed = 1;
        _ic.bounces = NO;
   
    

            }
    return _ic;
}

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return self.imageNames.count;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    
        view = [[UIView alloc] initWithFrame:self.view.bounds];
        UIImageView *imageView = [UIImageView new];
        imageView.tag = 100;
        [view addSubview:imageView];

        
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    
    UIImageView *imageView1 = (UIImageView *)[view viewWithTag:100];
   
    UIButton *gotoBt = [UIButton buttonWithType:UIButtonTypeSystem];
    imageView1.image = [UIImage imageNamed:self.imageNames[index]];
    
    if(index == 3){
        
          [imageView1 addSubview:gotoBt];
        [gotoBt setTitle:@"立即体验" forState:UIControlStateNormal];

        [gotoBt setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
       
        imageView1.userInteractionEnabled = YES;
        [gotoBt mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(imageView1.mas_centerX).mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(155, 35));
            make.bottom.mas_equalTo(imageView1.mas_bottom).mas_equalTo(-100);
        }];
        //跳转主页面
        [gotoBt bk_addEventHandler:^(id sender) {
            
            LoginViewController *vc2 = kVCFromSb(@"LoginViewController", @"Main");


            ResideViewController *vc = [[ResideViewController alloc]initWithContentViewController:[WTTBarController new] leftMenuViewController:vc2 rightMenuViewController:nil];
            
            [self presentViewController:vc animated:YES completion:nil];
            
        } forControlEvents:UIControlEventTouchUpInside];
    }else{
        if (index == 0) {
                gotoBt.hidden = YES;
       
        imageView1.userInteractionEnabled = NO;
        }
    
    }

    return view;
}

//监控当前滚到第几个
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel{
    _pageControl.currentPage = carousel.currentItemIndex;
   }

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.ic];
    [self.view addSubview:self.pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX).mas_equalTo(0);
        make.bottom.mas_equalTo(self.view.mas_bottom).mas_equalTo(-60);
        
    }];
  
    [self.ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (CGFloat )carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    //设置不循环滚动
    if (option == iCarouselOptionWrap) {
        return NO;
    }
    
    //取消背后的显示
    if (option == iCarouselOptionShowBackfaces) {
        return NO;
    }
    

    return value;
}


//选中的那个Item

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
