//
//  WelcomeViewController.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iCarousel.h"

@interface WelcomeViewController : UIViewController





@end
