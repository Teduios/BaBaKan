//
//  ResideViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ResideViewController.h"
#import "WTTBarController.h"
#import "LoginViewController.h"

@interface ResideViewController ()


@end

@implementation ResideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置翻转效果
    self.contentViewScaleValue = 2;
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
   }



@end
