//
//  ResideViewController.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RESideMenu.h"

@interface ResideViewController : RESideMenu

@end
