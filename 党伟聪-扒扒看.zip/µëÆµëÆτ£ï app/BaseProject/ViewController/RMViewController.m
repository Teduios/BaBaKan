//
//  RMViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RMViewController.h"
#import "SmallCell.h"
#import "BigCell.h"
#import "WTTViewModel.h"
#import "RMDetailViewController.h"
#import "LoadingView.h"

@interface RMViewController ()<UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UICollectionViewDelegate>

@property(nonatomic,strong)UICollectionView *collectionView;
@property(nonatomic,strong)WTTViewModel *rmVM;

@end

@implementation RMViewController

- (WTTViewModel *)rmVM{
    if (!_rmVM) {
        _rmVM = [[WTTViewModel alloc] initWithType:_WTTType.integerValue];
    }
    return _rmVM;
}



- (UICollectionView *)collectionView{
    if (!_collectionView) {
        UICollectionViewFlowLayout *Flayout = [[UICollectionViewFlowLayout alloc] init];
        Flayout.minimumLineSpacing = 5.0f;
        
        [Flayout setScrollDirection:UICollectionViewScrollDirectionVertical];
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, -10, kWindowW, kWindowH) collectionViewLayout:Flayout];

        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        
        _collectionView.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:_collectionView];
        [self.collectionView registerClass:[BigCell class] forCellWithReuseIdentifier:@"BigCell"];
        [self.collectionView registerClass:[SmallCell class] forCellWithReuseIdentifier:@"SmallCell"];
        
    }
    return _collectionView;
}



#pragma mark - CollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.rmVM.rowNumber;
}




- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

  if (indexPath.row %7 == 0) {
      
     
      BigCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"BigCell" forIndexPath:indexPath];
      
        [cell.contentView addSubview:cell.BigimageView];
        [cell.BigimageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
            
        }];
        [cell.BigimageView setImageWithURL:[self.rmVM imsrcURLForRow:indexPath.row]];

    
        [cell.BigimageView addSubview:cell.titlelb];
        [cell.titlelb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            
            make.size.mas_equalTo(CGSizeMake(kWindowW, 50));
        }];
        cell.titlelb.text = [self.rmVM titleForRow:indexPath.row];
      cell.titlelb.textAlignment = NSTextAlignmentCenter;
        cell.titlelb.backgroundColor = [UIColor blackColor];
    cell.titlelb.font = [UIFont systemFontOfSize:15];
    cell.titlelb.numberOfLines = 0;
    
    cell.titlelb.textColor = [UIColor whiteColor];
    cell.titlelb.alpha = 0.7;
    
    
    
        [cell.titlelb addSubview:cell.visitlb];
        [cell.visitlb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-5);
            make.bottom.mas_equalTo(-5);
            make.size.mas_equalTo(CGSizeMake(30, 8));
        }];
    cell.visitlb.textColor = [UIColor whiteColor];
    cell.visitlb.font = [UIFont systemFontOfSize:10];
        cell.visitlb.text = [NSString stringWithFormat:@"%.0lf",[self.rmVM visitNumForRow:indexPath.row]];
    
    [cell.titlelb addSubview:cell.SmallimageView];

    cell.SmallimageView.image = [UIImage imageNamed:@"eye-icon_dark"];
    [cell.SmallimageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(cell.visitlb.mas_left).mas_equalTo(-3);
        make.bottomMargin.mas_equalTo(cell.visitlb);
        make.size.mas_equalTo(CGSizeMake(15, 10));
        
    }];
    
        return cell;
  }

   SmallCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SmallCell" forIndexPath:indexPath];
    
    [cell.contentView addSubview:cell.BigimageView];

    [cell.BigimageView setImageWithURL:[self.rmVM imsrcURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"joke_no_load"]];
    [cell.BigimageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.mas_equalTo(0);
        
            make.size.height.mas_equalTo(120);
        }];

    
    [cell.contentView addSubview:cell.titlelb];
    cell.titlelb.text = [self.rmVM titleForRow:indexPath.row];
        cell.titlelb.numberOfLines = 0;
        cell.titlelb.textColor = [UIColor grayColor];
        cell.titlelb.font = [UIFont systemFontOfSize:13];
    cell.titlelb.backgroundColor = [UIColor whiteColor];
        [cell.titlelb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.top.mas_equalTo(cell.BigimageView.mas_bottom).mas_equalTo(0);
            
        }];

    
    
    
    [cell.BigimageView addSubview:cell.visitlb];
    if ([self.rmVM visitNumForRow:indexPath.row] > 10000) {
         cell.visitlb.text = [NSString stringWithFormat:@"%.0lf万+",[self.rmVM visitNumForRow:indexPath.row]/10000];
    }else{
    cell.visitlb.text = [NSString stringWithFormat:@"%.0lf",[self.rmVM visitNumForRow:indexPath.row]];
    }
        cell.visitlb.font = [UIFont systemFontOfSize:10];
        cell.visitlb.textColor = [UIColor whiteColor];
        [cell.visitlb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(cell.BigimageView.mas_right).mas_equalTo(-5);
            make.bottom.mas_equalTo(cell.BigimageView.mas_bottom).mas_equalTo(-5);
            make.size.mas_equalTo(CGSizeMake(30, 10));
        }];
    
    
    
    [cell.BigimageView addSubview:cell.SmallimageView];
    cell.SmallimageView.image = [UIImage imageNamed:@"eye-icon_dark"];
    [cell.SmallimageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(cell.visitlb.mas_left).mas_equalTo(-3);
            make.bottomMargin.mas_equalTo(cell.visitlb);
            make.size.mas_equalTo(CGSizeMake(15, 10));
    
      }];
    
    
    return cell;


    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    CGFloat width = 0;
    CGFloat height = 0;
       if (indexPath.row % 7 == 0) {
        width = kWindowW;
        height = kWindowW * 484/714;
        return CGSizeMake(width, height);
    }
    width = (kWindowW-20) * 0.5;
     height = kWindowW *200/328;
    
    
 return CGSizeMake(width, height);
    
    
    
}


- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
  
    return UIEdgeInsetsMake(5, 5, 5, 5);
}






- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{

        
    RMDetailViewController *vc =[[RMDetailViewController alloc] initWithId:[self.rmVM IdForRow:indexPath.row] AckCode:[self.rmVM ackForRow:indexPath.row]];
        [self.navigationController pushViewController:vc animated:YES];
        
        
 
    
}

//界面即将显示效果
- (void)viewWillAppear:(BOOL)animated{

    [LoadingView addViewToController:self];
    
}
- (void)viewDidAppear:(BOOL)animated{
    [LoadingView removeView];
   
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.collectionView.backgroundColor = kRGBColor(222, 212, 198);

    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.rmVM refreshDataCompletionHandle:^(NSError *error) {
            [self.collectionView.header endRefreshing];
            [self.collectionView reloadData];
        }];
        
    }];
    
    [self.collectionView.header beginRefreshing];
    
    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.rmVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.collectionView.footer endRefreshing];
            [self.collectionView reloadData];
        }];
    }];

    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
