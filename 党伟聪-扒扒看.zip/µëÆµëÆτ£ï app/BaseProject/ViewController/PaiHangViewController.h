//
//  PaiHangViewController.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Factory.h"
#import "WMPageController.h"

@interface PaiHangViewController :WMPageController

+(UINavigationController *)standarWTTPHNavi;


@end
