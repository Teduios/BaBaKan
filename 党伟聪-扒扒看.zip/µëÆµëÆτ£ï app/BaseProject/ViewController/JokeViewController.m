//
//  JokeViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "JokeViewController.h"
#import "JokeCell.h"
#import "ReadViewController.h"

@interface JokeViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)JokeViewModel *jokeVM;
//定义一个分段控件
@property(nonatomic,strong)UISegmentedControl *segment;

@end

@implementation JokeViewController

- (UISegmentedControl *)segment{
    if (!_segment) {
        _segment = [[UISegmentedControl alloc] initWithFrame:CGRectMake(0, 0, 80, 25)];
        //设置分段控件的文字样式
        
        NSDictionary *titleDic = @{NSFontAttributeName : [UIFont systemFontOfSize:15],NSForegroundColorAttributeName : [UIColor whiteColor]};
        NSDictionary *titleDic2 = @{NSFontAttributeName : [UIFont systemFontOfSize:13],NSForegroundColorAttributeName : kRGBColor(0, 91, 255)};
        
        
        

        [_segment setTitleTextAttributes:titleDic forState:UIControlStateSelected];
        [_segment setTitleTextAttributes:titleDic2 forState:UIControlStateNormal];
        [_segment insertSegmentWithTitle:@"段子" atIndex:0 animated:YES];
        _segment.selectedSegmentIndex = 0;
        [_segment insertSegmentWithTitle:@"读书" atIndex:1 animated:YES];
        [self.segment addTarget:self action:@selector(selectedVC:) forControlEvents:UIControlEventValueChanged];
        

    }
    return _segment;
}

- (JokeViewModel *)jokeVM{
    if (!_jokeVM) {
        _jokeVM = [JokeViewModel new];
    }
    return _jokeVM;
}


//初始化table加载数据
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.jokeVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.header endRefreshing];
                
            }];
            
        }];
        [self.tableView.header beginRefreshing];
        _tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            [self.jokeVM getMoreDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.footer endRefreshing];
                
            }];
            
        }];
        
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
            
        }];
        [self.tableView registerClass:[JokeCell class] forCellReuseIdentifier:@"TitleCell"];
        [self.tableView registerClass:[hasPicCell class] forCellReuseIdentifier:@"PicCell"];
        [self.tableView registerClass:[hasPicAndContentCell class] forCellReuseIdentifier:@"PicAndConCell"];
  
        
    }
    return _tableView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = NO;
    self.view.backgroundColor = [UIColor whiteColor];
    //把控件加到导航栏上面
    [self.navigationController.navigationBar.topItem setTitleView:self.segment];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

//实现uisegmentIndex的方法
-(void)selectedVC : (id )sender {

    ReadViewController *vc = [ReadViewController new];
    JokeViewController *vc2 = [JokeViewController new];
    UISegmentedControl *control = (UISegmentedControl *)sender;
    switch (control.selectedSegmentIndex) {
        case 0:
            
            [self.view addSubview:vc2.view];
            vc2.view.frame = self.view.bounds;
  
            break;
        case 1:
            

            [self.view addSubview:vc.view];
            vc.view.frame = self.view.bounds;
            
            break;
            
        default:
            break;
    }
    
}

#pragma mark - UITableDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}


//显示三个cell中的内容

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    /**
     *  只有文字
     */
    if ( [self.jokeVM JokeBodyModelForRow:indexPath.section].content.length != 0 && [self.jokeVM JokeBodyModelForRow:indexPath.section].img.count == 0) {
        JokeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TitleCell"];
        cell.view.alpha = 1;
        cell.view.backgroundColor = kRGBColor(255, 255, 230);

        cell.title.text = [self.jokeVM contentForRow:indexPath.section];
        cell.like.text = [NSString stringWithFormat:@"%ld",(long)[self.jokeVM likesForRow:indexPath.section]];
        cell.contentCount.text = [NSString stringWithFormat:@"%ld",(long)[self.jokeVM commentsallForRow:indexPath.section]];
        cell.likeIV.image = [UIImage imageNamed:@"点赞icon-1"];
        cell.contentIV.image = [UIImage imageNamed:@"评论0"];
        
        return cell;
    }
    /**
     *  只有图片
     */
    if([self.jokeVM JokeBodyModelForRow:indexPath.section].content.length == 0 && [self.jokeVM JokeBodyModelForRow:indexPath.section].img.count != 0){
        
        hasPicCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PicCell"];
        cell.view.alpha = 1;
         cell.view.backgroundColor = kRGBColor(255, 255, 230);
   
        cell.like.text = [NSString stringWithFormat:@"%ld",(long)[self.jokeVM likesForRow:indexPath.section]];
        cell.contentCount.text = [NSString stringWithFormat:@"%ld",(long)[self.jokeVM commentsallForRow:indexPath.section]];
        [cell.detailIV setImageWithURL:[self.jokeVM imgURLForRow:indexPath.section] placeholderImage:[UIImage imageNamed:@"joke_no_load"]];
        cell.likeIV.image = [UIImage imageNamed:@"点赞icon-1"];
        cell.contentIV.image = [UIImage imageNamed:@"评论0"];
        
        
        
        return cell;
        
        
        
    }
    
    
    /**
     *  有图有文字
     */
    hasPicAndContentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PicAndConCell"];
    cell.title.text = [self.jokeVM contentForRow:indexPath.section];
    //cell.title.backgroundColor = [UIColor redColor];
    cell.view.alpha = 1;
    cell.view.backgroundColor = kRGBColor(255, 255, 230);

    cell.like.text = [NSString stringWithFormat:@"%ld",(long)[self.jokeVM likesForRow:indexPath.section]];
   
    cell.contentCount.text = [NSString stringWithFormat:@"%ld",(long)[self.jokeVM commentsallForRow:indexPath.section]];
    [cell.detailIV setImageWithURL:[self.jokeVM imgURLForRow:indexPath.section] placeholderImage:[UIImage imageNamed:@"joke_no_load"]];
    cell.likeIV.image = [UIImage imageNamed:@"点赞icon-1"];
    cell.contentIV.image = [UIImage imageNamed:@"评论0"];
    
    
    
    return cell;
    
  
    
    
    
}








//去掉左侧缝线
kRemoveCellSeparator

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.jokeVM.SectionNumber;
}

//自适应高度
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

//返回cell头尾的高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 2;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 2;
}




@end
