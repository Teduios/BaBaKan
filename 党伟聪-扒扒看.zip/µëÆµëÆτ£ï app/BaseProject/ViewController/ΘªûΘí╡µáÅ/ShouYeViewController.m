//
//  ShouYeViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/8.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ShouYeViewController.h"
#import "ScrollDisplayViewController.h"
#import "WTTViewModel.h"
#import "HuDongViewController.h"
#import "MobClick.h"
#import "UMSocial.h"


#import "RMViewController.h"



@interface ShouYeViewController ()<UMSocialUIDelegate>

@end




@implementation ShouYeViewController

+(UINavigationController *)standardWTTNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        ShouYeViewController *vc = [[ShouYeViewController alloc] initWithViewControllerClasses:[self viewControllerClasses] andTheirTitles:[self itemNames]];
        vc.titleColorSelected = [UIColor redColor];
        vc.menuBGColor = [UIColor lightGrayColor];
        vc.titleSizeNormal = 17;
        vc.titleSizeSelected = 20;
        vc.menuViewStyle = WMMenuViewStyleLine;
        vc.menuHeight = 43;
       
        
         vc.keys = [self vcKeys];
      
        vc.values = [self vcValues];
      
        navi = [[UINavigationController alloc] initWithRootViewController:vc];
        
        
    });
    
    return navi;
    
}


+(NSArray *)itemNames{
    return @[@"热门",
             @"美女",
             @"互动",
             @"萌宠",
             @"奇趣",
             @"爆笑",
             @"微观",
             @"生活",
             @"资讯"];
}






+(NSArray *)viewControllerClasses{
    NSMutableArray *arr = [NSMutableArray new];
    
    for (int i = 0 ; i < [self itemNames].count;i++) {
        
        if (i == 2) {
            [arr addObject:[HuDongViewController class]];
            continue;
        }
        [arr addObject:[RMViewController class]];
    }
    return [arr copy];
}


//提供每个vc对应的values值数组
+(NSArray *)vcValues{
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i < [self itemNames].count; i++) {
        //
        [arr addObject:@(i)];
    }
    return arr;
}




//提供每个VC对应的key值数组

+ (NSArray *)vcKeys{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:@"WTTType"];
    }
    return [arr copy];
}

- (void)viewDidLoad {
    [super viewDidLoad];
   self.navigationItem.title = @"首页";
    
   
    
    
    [Factory addMenuItemToVC:self];
   // [Factory addMenuRightItemToVC:self];
   
    self.navigationController.navigationBar.backgroundColor = [UIColor lightGrayColor];
    
    
    [MobClick beginEvent:@"下载量"];
    [MobClick endEvent:@"下载量"];
    
    //添加分享按钮
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(0, 0, 30, 25);
    
    
    
    [btn setBackgroundImage:[UIImage imageNamed:@"分享0"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"分享1"] forState:UIControlStateHighlighted];

    [btn bk_addEventHandler:^(id sender) {
        
        [UMSocialSnsService presentSnsIconSheetView:self appKey:appleKey shareText:@"lookingNews,知你所不知" shareImage:[UIImage imageNamed:@"icon.png"] shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToQQ,UMShareToEmail,UMShareToWechatTimeline, nil] delegate:self];
  
          } forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *rigthItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.rightBarButtonItem = rigthItem;
    


 
}
/**
 *  友盟统计----页面   统计用户进入此页面的时长
 *
 * */
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"ShouYeViewController"];
    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"ShouYeViewController"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
