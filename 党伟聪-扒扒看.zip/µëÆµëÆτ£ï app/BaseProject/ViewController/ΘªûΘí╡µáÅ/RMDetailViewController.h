//
//  RMDetailViewController.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoadingView.h"
@interface RMDetailViewController : UIViewController
//点击需要改变的传入数据
-(id)initWithId:(NSString *)Id AckCode:(NSString *)ackcode;

@property (nonatomic,strong) LoadingView *loadV;
@end
