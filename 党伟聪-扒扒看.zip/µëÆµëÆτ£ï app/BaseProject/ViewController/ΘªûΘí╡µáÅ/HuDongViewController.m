//
//  HuDongViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HuDongViewController.h"
#import "WTTViewModel.h"
#import "BigCell.h"
#import "RMDetailViewController.h"

@interface HuDongViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>


@property(nonatomic,strong)UICollectionView *collectionView;
@property(nonatomic,strong)WTTViewModel *rmVM;


@end

@implementation HuDongViewController
- (WTTViewModel *)rmVM{
    if (!_rmVM) {
        _rmVM = [[WTTViewModel alloc] initWithType:WTTTypeHuDong];
    }
    return _rmVM;
}


//定义collectionView
- (UICollectionView *)collectionView{
    if (!_collectionView) {
        UICollectionViewFlowLayout *Flayout = [[UICollectionViewFlowLayout alloc] init];
        Flayout.minimumLineSpacing = 5.0f;
        
        [Flayout setScrollDirection:UICollectionViewScrollDirectionVertical];
        _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:Flayout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        
        _collectionView.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:_collectionView];
        [self.collectionView registerClass:[BigCell class] forCellWithReuseIdentifier:@"BigCell"];

        
    }
    return _collectionView;
}



#pragma mark - CollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.rmVM.rowNumber;
}




- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

        
        BigCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"BigCell" forIndexPath:indexPath];
        
        [cell.contentView addSubview:cell.BigimageView];
        [cell.BigimageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
            
        }];
        [cell.BigimageView setImageWithURL:[self.rmVM imsrcURLForRow:indexPath.row]];
   
        
        [cell.BigimageView addSubview:cell.titlelb];
        [cell.titlelb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            
            make.size.mas_equalTo(CGSizeMake(kWindowW, 50));
        }];
        cell.titlelb.text = [self.rmVM titleForRow:indexPath.row];
        cell.titlelb.textAlignment = NSTextAlignmentCenter;
        cell.titlelb.backgroundColor = [UIColor blackColor];
        cell.titlelb.font = [UIFont systemFontOfSize:15];
        cell.titlelb.numberOfLines = 0;
        
        cell.titlelb.textColor = [UIColor whiteColor];
        cell.titlelb.alpha = 0.7;
        
        
        
        [cell.titlelb addSubview:cell.visitlb];
        [cell.visitlb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-5);
            make.bottom.mas_equalTo(-5);
            make.size.mas_equalTo(CGSizeMake(30, 8));
        }];
        cell.visitlb.textColor = [UIColor whiteColor];
        cell.visitlb.font = [UIFont systemFontOfSize:10];
        cell.visitlb.text = [NSString stringWithFormat:@"%.0lf",[self.rmVM visitNumForRow:indexPath.row]];
        
        [cell.titlelb addSubview:cell.SmallimageView];
        //cell.SmallimageView.backgroundColor = [UIColor whiteColor];
        cell.SmallimageView.image = [UIImage imageNamed:@"eye-icon_dark"];
        [cell.SmallimageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(cell.visitlb.mas_left).mas_equalTo(-3);
            make.bottomMargin.mas_equalTo(cell.visitlb);
            make.size.mas_equalTo(CGSizeMake(15, 10));
            
        }];
        
        return cell;
 
}

//返回cell的高度
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    CGFloat width  = kWindowW-10;
    CGFloat height = kWindowW * 390/690;
  
    
        
    return CGSizeMake(width, height);
  
 
    
    
   
    
    
    
}

//点击实现跳转
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    RMDetailViewController *vc =[[RMDetailViewController alloc] initWithId:[self.rmVM IdForRow:indexPath.row] AckCode:[self.rmVM ackForRow:indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];
    
    
    
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
  
    self.collectionView.backgroundColor = kRGBColor(222, 212, 198);
    
    
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.rmVM refreshDataCompletionHandle:^(NSError *error) {
            [self.collectionView.header endRefreshing];
            [self.collectionView reloadData];
        }];
        
    }];
    
    [self.collectionView.header beginRefreshing];
    
    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.rmVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.collectionView.footer endRefreshing];
            [self.collectionView reloadData];
        }];
    }];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
