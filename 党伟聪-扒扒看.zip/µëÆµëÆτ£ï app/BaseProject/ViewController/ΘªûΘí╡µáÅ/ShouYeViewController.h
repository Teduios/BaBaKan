//
//  ShouYeViewController.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/8.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WMPageController.h"

@interface ShouYeViewController : WMPageController
+(UINavigationController *)standardWTTNavi;






@end
