//
//  ReadDetailViewController.h
//  BaseProject
//
//  Created by iOS1507a on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ReadViewModel.h"

@interface ReadDetailViewController : UIViewController

@property(nonatomic,strong)NSString *pathId;

-(id)initDocumentId:(NSString *)pathId;

@end
