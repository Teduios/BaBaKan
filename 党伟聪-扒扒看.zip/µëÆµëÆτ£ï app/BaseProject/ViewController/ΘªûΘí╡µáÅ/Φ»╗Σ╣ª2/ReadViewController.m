//
//  ReadViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ReadViewController.h"
#import "ReadDetailViewController.h"

@interface ReadViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)ReadViewModel *readVM;

@end

@implementation ReadViewController

- (ReadViewModel *)readVM{
    if (!_readVM) {
        _readVM = [ReadViewModel new];
        
    }
    return _readVM;
}


- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
       
        _tableView.dataSource = self;
        _tableView.delegate = self;
        NSLog(@"nodata");
        
        
        _tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.readVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self.tableView showErrorMsg:error.localizedDescription];
                }else{
                [self.tableView reloadData];
                }
                [self.tableView.header endRefreshing];
               
            }];
        }];
         [self.tableView.header beginRefreshing];
        self.tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            [self.readVM getMoreDataCompletionHandle:^(NSError *error) {
                NSLog(@"fdsfdsafdsg");
                if (error) {
                    [self.tableView showErrorMsg:error.localizedDescription];
                }else{
                    [self.tableView reloadData];
                }
                [self.tableView.footer endRefreshing];
            }];
        }];
        
         _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
        
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        //注册两种cell
        [self.tableView registerClass:[ReadCell class] forCellReuseIdentifier:@"Cell1"];
        [self.tableView registerClass:[ReadCell2 class] forCellReuseIdentifier:@"Cell2"];
        
        
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = NO;

    [[UINavigationBar appearance] setBackgroundColor:[UIColor lightGrayColor]];
    
   self.title = @"读书";
    
    
    

   
}

#pragma mark - UItableViewdelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.readVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        ReadCell2 *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell2"];
        cell.title.text = [self.readVM titleForRow:indexPath.row];
        [cell.iconIV setImageWithURL:[self.readVM imageForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"readingBG"]];
        return cell;
    }
    
    ReadCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell1"];
    cell.title.text = [self.readVM titleForRow:indexPath.row];
    [cell.iconIV setImageWithURL:[self.readVM imageForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"readingBG"]];
    cell.iconIV2.image = [UIImage imageNamed:@"eye-icon_dark"];
    
    NSString *timeStr = [self.readVM timeForRow:indexPath.row];
    cell.timetip.text = [timeStr substringFromIndex:10];
    cell.comments.text = [self.readVM comtentsForRow:indexPath.row];
    return cell;
    
   
    
}
kRemoveCellSeparator
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        return 190;
    }
    return 80;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
 
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
  
    NSString *str = [self.readVM detailForRow:indexPath.row];
    NSString *path = [str substringFromIndex:5];
    ReadDetailViewController *vc = [[ReadDetailViewController alloc]initDocumentId:path];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    
    [self presentViewController:nav animated:YES completion:nil];
   // [self.navigationController pushViewController:nav animated:YES];
   
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
