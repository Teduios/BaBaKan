//
//  ReadDetailViewController.m
//  BaseProject
//
//  Created by iOS1507a on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ReadDetailViewController.h"
#import "LoadingView.h"

@interface ReadDetailViewController ()<UIWebViewDelegate>
@property(nonatomic,strong)UIWebView *webView;

@end

@implementation ReadDetailViewController

-(id)initDocumentId:(NSString *)pathId{
    if (self = [super init]) {
        _pathId = pathId;
    }
    return self;
    
}

- (UIWebView *)webView{
    if (!_webView) {
        _webView = [[UIWebView alloc] init];
        _webView.delegate = self;
    
        [self.view addSubview:_webView];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.mas_equalTo(-64);
            make.bottom.right.left.mas_equalTo(0);
        }];
    }
    return _webView;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    

    self.navigationItem.title = @"读书详情";
    NSString *pathStr = [NSString stringWithFormat:@"http://i.ifeng.com/news/sharenews.f?aid=%@",_pathId];
   
    NSURL *pathUrl = [NSURL URLWithString:pathStr];
    NSURLRequest *request = [NSURLRequest requestWithURL:pathUrl];
    
    
    
    [self.webView loadRequest:request];
    //自定义返回按钮
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.image = [UIImage imageNamed:@"search_backward_ipad"];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]bk_initWithImage:imageView.image style:UIBarButtonItemStyleBordered handler:^(id sender) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - webViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
   
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)viewWillAppear:(BOOL)animated{
    [LoadingView addViewToController:self];
}

- (void)viewDidAppear:(BOOL)animated{
    [LoadingView removeView];
}
- (void)viewWillDisappear:(BOOL)animated{
    [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:NO];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
