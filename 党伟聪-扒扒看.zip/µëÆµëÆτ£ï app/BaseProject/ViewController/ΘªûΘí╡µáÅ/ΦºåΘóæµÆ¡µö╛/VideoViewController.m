//
//  VideoViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewController.h"
#import "VideoViewModel.h"
#import "VideoCell.h"

@interface VideoViewController ()<UITableViewDelegate,UITableViewDataSource>
//自定义tableView
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)VideoViewModel *videoVM;

@end

@implementation VideoViewController

- (VideoViewModel *)videoVM{
    if (!_videoVM) {
        _videoVM = [VideoViewModel new];
    }
    return _videoVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        
       _tableView.dataSource = self;
        _tableView.delegate = self;
        
        self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.videoVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    
                   
                    [_tableView reloadData];
                }
             [_tableView.header endRefreshing];
            }];
        }];
          [self.tableView.header beginRefreshing];
        
        _tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            [self.videoVM getMoreDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    
                    [_tableView reloadData];
                }
                [_tableView.footer endRefreshing];
            }];
        }];
        
      
        [self.view addSubview: _tableView];
        _tableView.tableFooterView = [UIView new];
        
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
            
        }];
        
        [self.tableView registerClass:[VideoCell class] forCellReuseIdentifier:@"Cell"];

           }

    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置分区的头尾的高度
    self.tableView.sectionHeaderHeight = 0;
    self.tableView.sectionFooterHeight = 0;
    
    //self.title = @"看看";
    self.navigationItem.title = @"视频列表";
    self.tableView.hidden = NO;
    
}
#pragma mark - tableViewdelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
     return self.videoVM.RowNumber;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
   return 1;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    VideoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.titleLb.text = [self.videoVM titleForRow:indexPath.section];

    [cell.iconBt setBackgroundImageForState:UIControlStateNormal withURL:[self.videoVM iconURLForRow:indexPath.section] placeholderImage:[UIImage imageNamed:@"videoBG"]];
    
   cell.lengthLb.text  = [NSString stringWithFormat:@"%ld:%ld",[self.videoVM lengthForRow:indexPath.section]/60,[self.videoVM lengthForRow:indexPath.section]%60];
    
    cell.playIV.image = [UIImage imageNamed:@"btn_play"];
    
    if ([self.videoVM playCountForRow:indexPath.section]>10000) {
            cell.playcount.text = [NSString stringWithFormat:@"%.0lf万+",[self.videoVM playCountForRow:indexPath.section]/10000];
    }else{
    cell.playcount.text = [NSString stringWithFormat:@"%.0lf",[self.videoVM playCountForRow:indexPath.section]];
    }
    
    cell.replyIV.image = [UIImage imageNamed:@"eye-icon_dark"];
    
    
    if ([self.videoVM replyForRow:indexPath.section]>10000) {
      cell.replyLb.text =[NSString stringWithFormat:@"%.0lf万+",[self.videoVM replyForRow:indexPath.section]/10000];
    }else{
    cell.replyLb.text =[NSString stringWithFormat:@"%.0lf",[self.videoVM replyForRow:indexPath.section]];
    }
    cell.videoURL = [self.videoVM videoURLForRow:indexPath.section];
    
    cell.playimage.image = [UIImage imageNamed:@"btn_play"];

    
    return cell;
    
}

kRemoveCellSeparator
//去掉选中的高亮状态
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
//返回适配的cell的高度
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}



@end
