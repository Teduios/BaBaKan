//
//  ReadViewModel.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ReadViewModel.h"


@implementation ReadViewModel

-(NSInteger)rowNumber{
    return self.dataArr.count;
}


- (NSString *)comtentsForRow:(NSInteger)row{
    return [self readItemForRow:row].comments;
}


- (FHItemModel *)readItemForRow:(NSInteger)row{
    return self.dataArr[row];
}

-(NSString *)timeForRow:(NSInteger)row{
    return [self readItemForRow:row].updateTime;
}

- (NSString *)titleForRow:(NSInteger)row{
    return [self readItemForRow:row].title;
}

-(NSURL *)imageForRow:(NSInteger)row{
    return [NSURL URLWithString: [self readItemForRow:row].thumbnail];
    
}


-(NSString *)detailForRow:(NSInteger)row{
    return [self readItemForRow:row].documentId;
}



- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [ReadNetManager getReadWithPage:_page completionHandle:^(ReadModel *model, NSError *error) {
        NSLog(@"modelllllll%@",model);
        if (!error) {
            [self.dataArr addObjectsFromArray:model.item];
            
        }
       
        
        completionHandle(error);
        
        
    }];
}

-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

@end
