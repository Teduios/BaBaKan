//
//  ReadViewModel.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ReadNetManager.h"

@interface ReadViewModel : BaseViewModel

@property (nonatomic) NSInteger rowNumber;

@property(nonatomic)NSInteger page;
//获取title
- (NSString *)titleForRow:(NSInteger)row;
//获取时间
- (NSString *)timeForRow:(NSInteger)row;
//图片
- (NSURL *)imageForRow:(NSInteger)row;
//详情
- (NSString *)detailForRow:(NSInteger)row;
//评论数
- (NSString *)comtentsForRow:(NSInteger)row;





@end
