//
//  LoginViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LoginViewController.h"
#import "UMSocial.h"

@interface LoginViewController ()<NSURLConnectionDataDelegate,NSURLConnectionDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *touXiangImageIV;

@property(nonatomic,strong)NSUserDefaults *userDefault;

@property (weak, nonatomic) IBOutlet UILabel *MyNameLb;

@end

@implementation LoginViewController


- (NSUserDefaults *)userDefault{
    if (!_userDefault) {
        _userDefault = [NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.touXiangImageIV.layer.cornerRadius = 30;
    self.touXiangImageIV.clipsToBounds = YES;

    NSString *MyName = [self.userDefault stringForKey:@"MyName"];
    
    NSString *ImageUrl= [self.userDefault stringForKey:@"MyImage"];
    NSLog(@"imageUrl%@",ImageUrl);

    self.MyNameLb.text = MyName;

    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:ImageUrl]];
    UIImage *imgae1 = [UIImage imageWithData:data];
    
    //主线程加载头像

    dispatch_async(dispatch_get_main_queue(), ^{

    self.touXiangImageIV.image = imgae1;
    
        
    });
    
    
}

- (IBAction)removeAcount:(UIButton *)sender {
    
    if ([self.userDefault stringForKey:@"MyName"] == nil) {
        [UIAlertView bk_showAlertViewWithTitle:nil message:@"请登录您的账号!" cancelButtonTitle:@"ok" otherButtonTitles:nil handler:nil];
    }else{
    
    [[UIAlertView bk_showAlertViewWithTitle:nil message:@"您确定要注销这个账号吗？" cancelButtonTitle:@"点错了" otherButtonTitles:@[@"心意已决"] handler:^(UIAlertView *alertView, NSInteger buttonIndex) {
        
        if (buttonIndex == 1) {
            [self.userDefault removeObjectForKey:@"MyName"];
            [self.userDefault removeObjectForKey:@"MyImage"];
            self.touXiangImageIV.image = nil;
            self.MyNameLb.text = nil;
        }
      
        
    }]show];
    }
    
    
    
    
    //[self.view setNeedsDisplay];
}

- (IBAction)QQLogin:(id)sender {
    
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToQQ];
    
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        
        //          获取微博用户名、uid、token等
        
        if (response.responseCode == UMSResponseCodeSuccess) {
            
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToQQ];
            
//            NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            self.MyNameLb.text = snsAccount.userName;
            self.touXiangImageIV.layer.cornerRadius = 30;
            [self.touXiangImageIV setImageWithURL:[NSURL URLWithString:snsAccount.iconURL]];
            
            
            
        }});
    
}

- (IBAction)sinaLogin:(id)sender {
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
    
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        
        //          获取微博用户名、uid、token等
        
//        if (response.responseCode == UMSResponseCodeSuccess) {
//            
//            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
        
//            NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
//            self.MyNameLb.text = snsAccount.userName;
//            [self.touXiangImageIV setImageWithURL:[NSURL URLWithString:snsAccount.iconURL]];

            
    //    }});
    
    //通过回调获取的信息
    [[UMSocialDataService defaultDataService] requestSnsInformation:UMShareToSina  completion:^(UMSocialResponseEntity *response){

        
        NSString *imageStr = [response.data valueForKey:@"profile_image_url"];
        NSLog(@"urlrulrururur:%@",[response.data valueForKey:@"profile_image_url"]);
//        NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:imageStr]];
//        [NSURLConnection connectionWithRequest:request delegate:self];
  
        NSString *myName = [response.data valueForKey:@"screen_name"];
        self.MyNameLb.text = myName;
        [self.touXiangImageIV setImageWithURL:[NSURL URLWithString:imageStr]];
        //保存文件到沙盒
        
        [self.userDefault setValue:myName forKey:@"MyName"];

        [self.userDefault setValue:imageStr forKey:@"MyImage"];
 
    }];
    });
    
}
                                  
    


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   }


@end
