//
//  RMDetailViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RMDetailViewController.h"

@interface RMDetailViewController ()<UIWebViewDelegate>

@property(nonatomic,strong)NSString *Id;
@property(nonatomic,strong)NSString *ackcode;
@property(nonatomic,strong)UIWebView *webview;
//存储加载图片的数组
@property(nonatomic,strong)NSMutableArray *allNames;
//加载图片
@property(nonatomic,strong)UIImageView *LoadingImageView;
@property(nonatomic,strong)UIView *loadBGView;
@property(nonatomic,strong)UIImageView *loadIV;

@end

@implementation RMDetailViewController






- (UIWebView *)webview{
    if (!_webview) {
        _webview = [[UIWebView alloc] init];
        
       [self.view addSubview:_webview];
        [_webview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _webview.delegate = self;
    }
    return _webview;
}


-(id)initWithId:(NSString *)Id AckCode:(NSString *)ackcode{
    if (self = [super init]) {
        _Id = Id;
        _ackcode = ackcode;
    }
    return self;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"新闻详情";
    self.navigationController.navigationBarHidden = NO;
    // Do any additional setup after loading the view.
    NSString *path = [NSString stringWithFormat:@"http://app.lerays.com/stream/app/view?stream_id=%@&_ack=%@&from=wtt-app",_Id,_ackcode];
   
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:path]];
    
    [self.webview loadRequest:request];
    
//自定义返回按钮
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.image = [UIImage imageNamed:@"search_backward_ipad"];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]bk_initWithImage:imageView.image style:UIBarButtonItemStyleBordered handler:^(id sender) {
        [self.navigationController popViewControllerAnimated:YES];
    }];

}
//跳转时 的动画效果
- (void)viewWillAppear:(BOOL)animated{
    

    self.loadV = [LoadingView new];
    [self.loadV addViewToController:self];

    

}

//remove 动画视图
- (void)viewDidAppear:(BOOL)animated{
    

    [self.loadV removeView];
    

}
- (void)viewWillDisappear:(BOOL)animated{
    [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:NO];
}


#pragma mark - webView

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];

}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error{

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
