//
//  ContentDetailViewController.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//http://app.lerays.com/stream/app/view?stream_id={stream_id}&_ack={ack_code}&from=wtt-app

#import <UIKit/UIKit.h>

@interface ContentDetailViewController : UIViewController

- (id)initWithId:(NSString *)Id Ackcode:(NSString *)ackcode;

@end
