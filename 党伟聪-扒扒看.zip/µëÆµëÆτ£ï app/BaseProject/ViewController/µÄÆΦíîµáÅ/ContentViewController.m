//
//  ContentViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ContentViewController.h"
#import "PaiHangViewModel.h"
#import "ContentDetailViewController.h"

#import "YHCell.h"

@interface ContentViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)PaiHangViewModel *bangVM;

@end

@implementation ContentViewController

- (PaiHangViewModel *)bangVM{
    if (_bangVM == nil) {
        _bangVM = [[PaiHangViewModel alloc] initWithType:_PHType.integerValue];
        
    }
    return _bangVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [UIView new];
        _tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.bangVM getDataFromNetCompleteHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.header endRefreshing];
            }];
        }];

    
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        [_tableView registerClass:[YHCell class] forCellReuseIdentifier:@"Cell"];
        
        
        
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView.header beginRefreshing];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.bangVM.rowNumber;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    YHCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.bigimageView setImageWithURL:[self.bangVM imsrcURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"joke_no_load"]];
    
    cell.titleLb.text = [self.bangVM titleForRow:indexPath.row];
    
    
    if ([self.bangVM visitNumForRow:indexPath.row] > 10000) {
        cell.visitNumber.text = [NSString stringWithFormat:@"%.0f万+",[self.bangVM visitNumForRow:indexPath.row]/10000];
        
    }else{
    cell.visitNumber.text = [NSString stringWithFormat:@"%.0f",[self.bangVM visitNumForRow:indexPath.row]];
    }
    
    [cell.smallImageView setImage:[UIImage imageNamed:@"eye-icon_dark"]];
    

  
            NSString *ImageName = [NSString stringWithFormat:@"%d",indexPath.row+1];
            cell.tipIV.image = [UIImage imageNamed:ImageName];

    return cell;
    
}

kRemoveCellSeparator

-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    ContentDetailViewController *vc = [[ContentDetailViewController alloc] initWithId:[self.bangVM IdForRow:indexPath.row] Ackcode:[self.bangVM ackForRow:indexPath.row]];
    
    [self.navigationController pushViewController:vc animated:YES];
    
    
    
}

@end
