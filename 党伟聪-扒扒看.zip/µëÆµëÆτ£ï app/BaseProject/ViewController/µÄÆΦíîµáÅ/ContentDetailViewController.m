//
//  ContentDetailViewController.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ContentDetailViewController.h"
#import "LoadingView.h"

@interface ContentDetailViewController ()<UIWebViewDelegate>

@property(nonatomic,strong)NSString *Id;
@property(nonatomic,strong)NSString *ackcode;
@property(nonatomic,strong)UIWebView *webview;

@end

@implementation ContentDetailViewController

-(UIWebView *)webview{
    if (!_webview) {
        _webview =[[UIWebView alloc]init];
        _webview.delegate = self;
        [self.view addSubview:_webview];
        [_webview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        
    }
    return _webview;
}

-(id)initWithId:(NSString *)Id Ackcode:(NSString *)ackcode{
    if (self = [super init]) {
        _Id = Id;
        _ackcode = ackcode;
        
    }
    return self;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *path = [NSString stringWithFormat:@"http://app.lerays.com/stream/app/view?stream_id=%@&_ack=%@&from=wtt-app",_Id,_ackcode];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:path]];
    
    [self.webview loadRequest:request];
    //自定义返回按钮
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.image = [UIImage imageNamed:@"search_backward_ipad"];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]bk_initWithImage:imageView.image style:UIBarButtonItemStyleBordered handler:^(id sender) {
        [self.navigationController popViewControllerAnimated:YES];
    }];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
- (void)viewWillAppear:(BOOL)animated{
    [LoadingView addViewToController:self];
}

- (void)viewDidAppear:(BOOL)animated{
    [LoadingView removeView];
}
- (void)viewWillDisappear:(BOOL)animated{
    [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:NO];
}

#pragma mark - webViewdelegate

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
