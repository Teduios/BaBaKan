//
//  WTTViewModel.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "WTTNetManager.h"

@interface WTTViewModel : BaseViewModel

//@property(nonatomic,strong)NSMutableArray *modelArr;



@property (nonatomic,strong) WTTDataModel *dataModel;


- (instancetype)initWithType:(WTTType)type;


//一个标识用于KVC的操作
@property(nonatomic)WTTType type;
@property(nonatomic)NSNumber* WTTType;



@property (nonatomic)NSInteger rowNumber;
@property(nonatomic,strong)NSString *pubtime;
@property (nonatomic,strong)NSString *creatSign;
@property (nonatomic,strong) NSString *cateId;//为固定的
@property (nonatomic,strong) NSString *netcateId;
@property (nonatomic,strong)NSString *nextTime;
@property (nonatomic,strong)NSString *nextSign;


//获取图片
//获取标题
/*获取评论数*/
//获取详情页的网址内容所需要的Id值
//获取详情页的网址内容所需要的ack_code值
//获取数据
- (NSURL *)imsrcURLForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;
- (double)visitNumForRow:(NSInteger)row;
- (NSString *)IdForRow:(NSInteger)row;
- (NSString *)ackForRow:(NSInteger)row;


@end
