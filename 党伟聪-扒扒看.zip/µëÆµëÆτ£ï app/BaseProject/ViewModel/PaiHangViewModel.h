//
//  PaiHangViewModel.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTViewModel.h"
#import "WTTNetManager.h"

@interface PaiHangViewModel : BaseViewModel

@property(nonatomic)PHType type2;
@property(nonatomic)NSNumber *PHType;


- (instancetype)initWithType:(PHType)type2;
//获取数组的count---->cell的数量
@property (nonatomic)NSInteger rowNumber;
//获取图片
- (NSURL *)imsrcURLForRow:(NSInteger)row;
//获取title
- (NSString *)titleForRow:(NSInteger)row;
//获取评论数
- (double)visitNumForRow:(NSInteger)row;

//详情页加载的要改变的值——Id
- (NSString *)IdForRow:(NSInteger)row;
//详情页加载的要改变的值——ack_code
- (NSString *)ackForRow:(NSInteger)row;











@end
