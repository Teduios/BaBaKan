//
//  VideoViewModel.m
//  BaseProject
//
//  Created by iOS1507a on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewModel.h"

@implementation VideoViewModel

-(NSInteger)RowNumber{
    return self.dataArr.count;
}

-(double)replyForRow:(NSInteger)row{
    return [self videoListForRow:row].replyCount;
}

-(NSInteger)lengthForRow:(NSInteger)row{
    return [self videoListForRow:row].length;
}


- (double)playCountForRow:(NSInteger)row{
    return [self videoListForRow:row].playCount;
}

- (VideoVideoListModel *)videoListForRow:(NSInteger)row{
    return self.dataArr[row];
}


- (NSString *)descForRow:(NSInteger)row{
    return [self videoListForRow:row].desc;
}

-(NSString *)titleForRow:(NSInteger)row{
    return [self videoListForRow:row].title;
}

-(NSURL *)iconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self videoListForRow:row].cover];
}

-(NSURL *)videoURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self videoListForRow:row].mp4Url];
}


//获取网络数据

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
   self.dataTask = [VideoNetManager getVideoWithIndex:_index completionHandle:^(VideoModel *model, NSError *error) {
       if (_index == 0) {
           [self.dataArr removeAllObjects];
       }
     
            [self.dataArr addObjectsFromArray:model.videoList];
            completionHandle(error);

    }];
}
//刷新
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _index = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}


//加载更多
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _index += 10;
    [self getDataFromNetCompleteHandle:completionHandle];
    
}

@end
