//
//  PaiHangViewModel.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PaiHangViewModel.h"

@implementation PaiHangViewModel


-(instancetype)initWithType:(PHType)type2{
    if (self = [self init]) {
        _type2 = type2;
    }
    return self;
}

- (NSInteger)rowNumber{
    return self.dataArr.count;
    
}


-(NSInteger)sectionNumber{
    return self.dataArr.count;
}

- (WTTDataListModel *)WTTDataListModeForRow:(NSInteger)row{
    return self.dataArr[row];
}


- (NSURL *)imsrcURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self WTTDataListModeForRow:row].img_src];
    
}

- (NSString *)titleForRow:(NSInteger)row{
    return [self WTTDataListModeForRow:row].title;
    
}

- (double)visitNumForRow:(NSInteger)row{
    return [self WTTDataListModeForRow:row].visit_num;
    
}


- (NSString *)IdForRow:(NSInteger)row{
    return [self WTTDataListModeForRow:row].Id;
}
- (NSString *)ackForRow:(NSInteger)row{
    return [self WTTDataListModeForRow:row].ack_code;
}











//获取数据
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    
    [WTTNetManager getPHType:_type2 completionHanle:^(WTTModel *model, NSError *error) {
        if (!error) {
            [self.dataArr addObjectsFromArray:model.data.list];
        }
        completionHandle(error);
    }];
    
}

//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    [self getDataFromNetCompleteHandle:completionHandle];
}





@end
