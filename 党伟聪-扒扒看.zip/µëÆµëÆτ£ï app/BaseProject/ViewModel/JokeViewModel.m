//
//  JokeViewModel.m
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "JokeViewModel.h"

@implementation JokeViewModel

- (NSInteger)SectionNumber{
    return self.dataArr.count;
}



//从数组中把对象提取出来
- (KidBodyModel *)JokeBodyModelForRow:(NSInteger)row{
    
    return self.dataArr[row];
}
//把数组下面的数组提取出来
- (kidbodyImg *)JokeBodyImgForRow:(NSInteger)row{
    return [self JokeBodyModelForRow:row].img.lastObject;
}
//返回图片
- (NSURL *)imgURLForRow:(NSInteger)row{
   NSString *path = [self JokeBodyImgForRow:row].url;
    return [NSURL URLWithString:path];
   
}


//点赞数
- (NSInteger)likesForRow:(NSInteger)row{
    return [self JokeBodyModelForRow:row].likes;
    
    
}
//评论数
- (NSInteger)commentsallForRow:(NSInteger)row{
    return [self JokeBodyModelForRow:row].commentsall;
    
}


//内容
- (NSString *)contentForRow:(NSInteger)row{
    return [self JokeBodyModelForRow:row].content;
    
}
//从网络获取数据

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [JokeNetManager getAddPage:_page completionHanle:^(KidModel *model, NSError *error) {
        if (!error) {
        [self.dataArr addObjectsFromArray:model.body];
            

        }
        completionHandle(error);
               
    }];
    
}

- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
    
}


- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

@end
