//
//  JokeViewModel.h
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "JokeNetManager.h"

@interface JokeViewModel : BaseViewModel

@property(nonatomic)NSInteger page;

@property(nonatomic)NSInteger SectionNumber;

//返回图片
- (NSURL *)imgURLForRow:(NSInteger)row;
//点赞数
- (NSInteger)likesForRow:(NSInteger)row;
//评论数
- (NSInteger)commentsallForRow:(NSInteger)row;

//内容
- (NSString *)contentForRow:(NSInteger)row;

- (KidBodyModel *)JokeBodyModelForRow:(NSInteger)row;





@end
