//
//  VideoViewModel.h
//  BaseProject
//
//  Created by iOS1507a on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "VideoNetManager.h"

@interface VideoViewModel : BaseViewModel
@property(nonatomic)NSInteger RowNumber;
//获取更多是加载的数据
@property(nonatomic)NSInteger index;

//标题
- (NSString *)titleForRow:(NSInteger)row;
//详解
-(NSString *)descForRow:(NSInteger)row;
//图片
- (NSURL *)iconURLForRow:(NSInteger)row;
//视频
-(NSURL *)videoURLForRow:(NSInteger)row;

//评论数

- (double)replyForRow:(NSInteger)row;
//视频长度

- (NSInteger)lengthForRow:(NSInteger)row;

- (double)playCountForRow:(NSInteger)row;



@end
