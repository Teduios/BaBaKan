//
//  LoadingView.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

/*封装一个类用显示详情的跳转动画*/

#import <UIKit/UIKit.h>

@interface LoadingView : NSObject

@property (nonatomic,strong) UIImageView *imageView;
@property(nonatomic,strong) UIView *loadView;
//添加加载界面
-(void)addViewToController:(UIViewController *)VC;
//删除加载界面
-(void)removeView;
//添加加载界面 -- 类方法
+(void)addViewToController:(UIViewController *)VC;
//删除加载界面 -- 类方法
+(void)removeView;

@end
