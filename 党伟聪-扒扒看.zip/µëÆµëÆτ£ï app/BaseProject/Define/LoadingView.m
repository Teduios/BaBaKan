//
//  LoadingView.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LoadingView.h"

@implementation LoadingView



- (void)addViewToController:(UIViewController *)VC{
//创建一个View

    self.loadView = [UIView new];
    _loadView.backgroundColor = [UIColor whiteColor];
    [VC.view addSubview:_loadView];
    [_loadView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
        
    }];
    //创建一个图片界面
   self.imageView = [UIImageView new];
    [_loadView addSubview:_imageView];
    [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(40, 40));

    }];
    
    //一个数组
    NSMutableArray *allNames = [NSMutableArray new];
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        for (int i = 1; i < 63 ; i++) {
            NSString *imageName = [NSString stringWithFormat:@"加载动画_%d",i];
            UIImage *image = [UIImage imageNamed:imageName];
            [allNames addObject:image];
            
        };
        
        dispatch_async(dispatch_get_main_queue(), ^{

            _imageView.animationImages = allNames;
            
            //动画时长
            _imageView.animationDuration = 63 * 0.05;
            //重复次数
            _imageView.animationRepeatCount = 5;
            [_imageView startAnimating];
        });
    });
  
}


- (void)removeView{
    [self.loadView removeFromSuperview];
    [self.imageView removeFromSuperview];
    
}


//设置一个全局的变量
static  UIView *loadView;
static  UIImageView *imageView;

+(void)addViewToController:(UIViewController *)VC{
   loadView = [UIView new];
    loadView.backgroundColor = [UIColor whiteColor];
    [VC.view addSubview:loadView];
    [loadView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
        
    }];
    //创建一个图片界面
    
  imageView = [UIImageView new];
    [loadView addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(40, 40));
        
    }];
    
    //一个数组
    NSMutableArray *allNames = [NSMutableArray new];
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        for (int i = 1; i < 63 ; i++) {
            NSString *imageName = [NSString stringWithFormat:@"加载动画_%d",i];
            UIImage *image = [UIImage imageNamed:imageName];
            [allNames addObject:image];
            
        };
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            imageView.animationImages = allNames;
            
            //动画时长
            imageView.animationDuration = 63 * 0.05;
            //重复次数
            imageView.animationRepeatCount = 5;
            [imageView startAnimating];
        });
    });

    
}

//删除加载界面
+(void)removeView{
    [loadView removeFromSuperview];
    [imageView removeFromSuperview];

    
}



@end
