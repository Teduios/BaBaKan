//
//  YHCell.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "YHCell.h"

@implementation YHCell

- (UIImageView *)tipIV{
    if (!_tipIV) {
        _tipIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_tipIV];
        [_tipIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(0);
            make.right.mas_equalTo(-0);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];
        
    }
    return _tipIV;
}


- (UIImageView *)bigimageView{
    if (!_bigimageView) {
        _bigimageView = [[UIImageView alloc] init];
        [self.contentView addSubview:_bigimageView];
        [_bigimageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(5);
            make.top.mas_equalTo(5);
            make.centerY.mas_equalTo(0);

            make.size.mas_equalTo(CGSizeMake(90, 70));
        
            
        }];
        
    }
    
    return _bigimageView;
    
}

- (UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [UILabel new];
        [self.contentView addSubview:_titleLb];
       
        _titleLb.numberOfLines = 0;
        _titleLb.font = [UIFont systemFontOfSize:15];
        _titleLb.textAlignment = NSTextAlignmentLeft;
        _titleLb.textColor = [UIColor blackColor];
        
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.left.mas_equalTo(self.bigimageView.mas_right).mas_equalTo(5);
          make.size.mas_equalTo(CGSizeMake(200, 40));
            
            
        }];
    }
    return _titleLb;
}


- (UILabel *)visitNumber{
    if (!_visitNumber) {
        _visitNumber = [UILabel new];
        [self.contentView addSubview:_visitNumber];
        _visitNumber.font = [UIFont systemFontOfSize:11];
        _visitNumber.textAlignment = NSTextAlignmentRight;
       
        [self.visitNumber mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-5);
            make.bottom.mas_equalTo(-5);
           make.size.mas_equalTo(CGSizeMake(30, 10));
            
        }];
    }
    return _visitNumber;
}

- (UIImageView *)smallImageView{
    if (!_smallImageView) {
        _smallImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:_smallImageView];
        [self.smallImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.visitNumber.mas_centerY);
            make.size.mas_equalTo(CGSizeMake(15, 10));
            make.right.mas_equalTo(self.visitNumber.mas_left).mas_equalTo(-3);
            
        }];
        
        
    }
    return _smallImageView;
    
}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
