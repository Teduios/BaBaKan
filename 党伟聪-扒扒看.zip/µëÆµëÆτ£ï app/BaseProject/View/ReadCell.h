//
//  ReadCell.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReadCell : UITableViewCell



@property (nonatomic,strong) UILabel *title;
@property (nonatomic,strong) UILabel *timetip;
@property (nonatomic,strong) UILabel *comments;
@property (nonatomic,strong) UIImageView *iconIV;
@property (nonatomic,strong) UIImageView *iconIV2;


@end


@interface ReadCell2 : UITableViewCell
@property (nonatomic,strong) UILabel *title;
@property (nonatomic,strong) UIImageView *iconIV;
@end
