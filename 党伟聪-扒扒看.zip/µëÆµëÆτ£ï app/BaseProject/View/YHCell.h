//
//  YHCell.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YHCell : UITableViewCell
@property (nonatomic,strong) UIImageView *bigimageView;
@property (nonatomic,strong) UILabel *titleLb;
@property (nonatomic,strong) UILabel *visitNumber;
@property (nonatomic,strong) UIImageView *smallImageView;

@property(nonatomic,strong)UIImageView *tipIV;



@end
