//
//  BigCell.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BigCell : UICollectionViewCell
@property (nonatomic,strong)UIImageView *BigimageView;
@property (nonatomic,strong) UILabel *titlelb;
@property (nonatomic,strong) UILabel *visitlb;
@property (nonatomic,strong) UIImageView *SmallimageView;




@end
