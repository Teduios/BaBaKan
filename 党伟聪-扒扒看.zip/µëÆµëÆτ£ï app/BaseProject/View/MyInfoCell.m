//
//  MyInfoCell.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MyInfoCell.h"

@implementation MyInfoCell

- (UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [UILabel new];
        _titleLb.font = [UIFont systemFontOfSize:15];
        _titleLb.textColor = [UIColor blackColor];
        
        
        
    }
    return _titleLb;
}

- (UILabel *)detailLb{
    if (!_detailLb) {
        _detailLb.font = [UIFont systemFontOfSize:10];
        _detailLb.textColor = [UIColor blackColor];
        _detailLb.backgroundColor = [UIColor redColor];
        
       
        
    }
    return _detailLb;
}

- (UIImageView *)imageIcon{
    if (!_imageIcon) {
        _imageIcon = [[UIImageView alloc]init];
        
    }
    return _imageIcon;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
     self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        [self.contentView addSubview:self.titleLb];
        [self.contentView addSubview:self.detailLb];
        [self.contentView addSubview:self.imageIcon];
        
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(self.imageIcon.mas_right).mas_equalTo(10);
            
        }];
        
        [self.detailLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.right.mas_equalTo(self.contentView.mas_left).mas_equalTo(-50);
 
        }];
        
        [self.imageIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.centerY.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(30, 30));
            
        }];


        

        

        
        
        
        
        
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
