//
//  VideoCell.h
//  BaseProject
//
//  Created by iOS1507a on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoCell : UITableViewCell

@property(nonatomic,strong)UIButton *iconBt;
@property(nonatomic,strong)UILabel *titleLb;

@property(nonatomic,strong)UILabel *replyLb;
@property(nonatomic,strong)UILabel *lengthLb;
@property(nonatomic,strong)UILabel *playcount;
@property(nonatomic,strong)UIView *bottomview;
@property (nonatomic,strong) UIImageView *playIV;
@property (nonatomic,strong) UIImageView *replyIV;
@property(nonatomic,strong)UIImageView *playimage;

@property(nonatomic,strong)NSURL *videoURL;

@end
