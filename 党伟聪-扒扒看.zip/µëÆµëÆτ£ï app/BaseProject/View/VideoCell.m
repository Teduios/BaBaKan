//
//  VideoCell.m
//  BaseProject
//
//  Created by iOS1507a on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCell.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

@implementation VideoCell

//为了保证同时只有一个播放器，使用单例模式

+ (AVPlayerViewController *)sharedInstance{
    static AVPlayerViewController *vc =nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [AVPlayerViewController new];
        
    });
    return vc;
}


-(UIImageView *)playimage{
    if (!_playimage) {
        _playimage = [[UIImageView alloc]init];
        [_iconBt addSubview:_playimage];
    [_playimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(self.iconBt);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    }
    return _playimage;
}
- (UIButton *)iconBt{
    if (!_iconBt) {
        _iconBt = [UIButton buttonWithType:0];
        [self.contentView addSubview:_iconBt];
        [_iconBt mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(0);
            
            make.size.height.mas_equalTo(200);
            
            
            
        }];
        
        
        [_iconBt bk_addEventHandler:^(id sender) {
            AVPlayer *player = [AVPlayer playerWithURL:self.videoURL];
            [player play];
            [VideoCell sharedInstance].player = player;
            [sender addSubview:[VideoCell sharedInstance].view];
            [[VideoCell sharedInstance].view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(0);
                
            }];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _iconBt;
}

//如果cell被复用 需要把cell的播放器删掉
- (void)prepareForReuse{
    [super prepareForReuse];
    if ([VideoCell sharedInstance].view.superview == self.iconBt) {
        [[VideoCell sharedInstance].view removeFromSuperview];
        [VideoCell sharedInstance].player = nil;
    }
}


-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc] init];
        [self.iconBt addSubview:_titleLb];
        
        _titleLb.font = [UIFont systemFontOfSize:17];
        _titleLb.textColor = [UIColor whiteColor];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.size.height.mas_equalTo(40);
        }];
    }
    return _titleLb;
}

- (UILabel *)lengthLb{
    if (!_lengthLb) {
        _lengthLb = [UILabel new];
        [self.iconBt addSubview:_lengthLb];
        _lengthLb.font = [UIFont systemFontOfSize:11];
        _lengthLb.textAlignment = NSTextAlignmentCenter;
        _lengthLb.backgroundColor = [UIColor lightGrayColor];
        [self.lengthLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.bottom.mas_equalTo(self.iconBt.mas_bottom).mas_equalTo(-5);
            make.size.mas_equalTo(CGSizeMake(40, 10));
            
        }];
        
    }
    return _lengthLb;
}


- (UIView *)bottomview{
    if (!_bottomview ) {
        _bottomview = [UIView new];
        [self.contentView addSubview:_bottomview];
        [_bottomview mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.mas_equalTo(self.iconBt.mas_bottom).mas_equalTo(0);
            make.right.left.mas_equalTo(0);
            make.size.height.mas_equalTo(40);
            make.bottom.mas_equalTo(0);
        }];
        
    }
    return _bottomview;
}

- (UIImageView *)playIV{

    if (!_playIV) {
        _playIV = [UIImageView new];
        [self.bottomview addSubview:_playIV];
        
        [_playIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.bottomview.mas_centerY).mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.left.mas_equalTo(10);
            
        }];
    }
    return _playIV;
}

- (UILabel *)playcount{
    if (!_playcount) {
        _playcount = [UILabel new];
        [self.bottomview addSubview:_playcount];
        _playcount.font = [UIFont systemFontOfSize:11];
        [_playcount mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.playIV.mas_right).mas_equalTo(5);
            make.size.mas_equalTo(CGSizeMake(40, 10));
            make.centerY.mas_equalTo(self.bottomview.mas_centerY).mas_equalTo(0);
            
        }];
        
    }
    return _playcount;
}


-(UIImageView *)replyIV{
    if (!_replyIV) {
        _replyIV= [[UIImageView alloc]init];
        [self.bottomview addSubview:_replyIV];
        [_replyIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.playcount.mas_right).mas_equalTo(30);
            make.centerY.mas_equalTo(self.bottomview.mas_centerY).mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(20, 15));
            
        }];
    }
    return _replyIV;
}
-(UILabel *)replyLb{
    if (!_replyLb) {
        _replyLb = [UILabel new];
        
        [self.bottomview addSubview:_replyLb];
        
        _replyLb.font = [UIFont systemFontOfSize:11];
        [_replyLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.replyIV.mas_right).mas_equalTo(5);
            make.centerY.mas_equalTo(self.bottomview.mas_centerY).mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(30, 10));
        }];
        
        
    }
    return _replyLb;
    
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
