//
//  JokeCell.m
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "JokeCell.h"
//只有title
@implementation JokeCell
//
- (UILabel *)title{
    if (!_title) {
        _title = [UILabel new];
        _title.numberOfLines = 0;
        _title.font = [UIFont systemFontOfSize:17];
        _title.textColor = [UIColor blackColor];
        [self.contentView addSubview:_title];
        [_title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.right.mas_equalTo(-10);

            make.bottom.mas_equalTo(self.view.mas_top).mas_equalTo(-5);
  
        }];

        
    }
    return _title;
}

- (UILabel *)like{
    if (!_like) {
        _like = [UILabel new];
        _like.font = [UIFont systemFontOfSize:10];
        _like.textColor = [UIColor lightGrayColor];
        [self.view addSubview:_like];
        [_like mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 25));
            make.left.mas_equalTo(self.likeIV.mas_right).mas_equalTo(5);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];
    }
    return _like;
}

-  (UILabel *)contentCount{
    if (!_contentCount) {
        _contentCount = [UILabel new];
        _contentCount.font = [UIFont systemFontOfSize:10];
        _contentCount.textColor = [UIColor lightGrayColor];
        [self.view addSubview:_contentCount];
        [_contentCount mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 25));
            make.right.mas_equalTo(-10);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];
    }
    return  _contentCount;
}


- (UIImageView *)contentIV{
    if (!_contentIV ) {
        _contentIV = [UIImageView new];
        [self.view addSubview:_contentIV];
        [_contentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.right.mas_equalTo(self.contentCount.mas_left).mas_equalTo(-10);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];
    }
    return _contentIV;
}
- (UIImageView *)likeIV{
    if (!_likeIV ) {
        _likeIV = [UIImageView new];
        [self.view addSubview:_likeIV];
        [_likeIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.left.mas_equalTo(10);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];

    }
    return _likeIV;
}

- (UIView *)view{
    if (!_view) {
        _view = [UIView new];
        
        _view.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:_view];
        [_view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(0);
            make.size.height.mas_equalTo(40);
           // make.top.mas_equalTo(self.title.mas_bottom).mas_equalTo(0);
            
        }];

        
        
    }
    return _view;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {


    }
    return self;
    
}


@end










//只有图片

@implementation hasPicCell

- (UIImageView *)detailIV{
    if (!_detailIV) {
        _detailIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_detailIV];
        [_detailIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.left.top.mas_equalTo(10);
            make.size.height.mas_equalTo(700 * kWindowW / 672);
            make.bottom.mas_equalTo(self.view.mas_top).mas_equalTo(0);
            
            
        }];
        
        
    }
    return _detailIV;
}

- (UILabel *)like{
    if (!_like) {
        _like = [UILabel new];
        _like.font = [UIFont systemFontOfSize:10];
        _like.textColor = [UIColor lightGrayColor];
        [self.view addSubview:_like];
        [_like mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(40, 25));
            make.left.mas_equalTo(self.likeIV.mas_right).mas_equalTo(5);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];

    }
    return _like;
}

-  (UILabel *)contentCount{
    if (!_contentCount) {
        _contentCount = [UILabel new];
        _contentCount.font = [UIFont systemFontOfSize:10];
        _contentCount.textColor = [UIColor lightGrayColor];
        [self.view addSubview:_contentCount];
        [_contentCount mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 25));
            make.right.mas_equalTo(-10);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];
    }
    return  _contentCount;
}


- (UIImageView *)contentIV{
    if (!_contentIV ) {
        _contentIV = [UIImageView new];
        [self.view addSubview:_contentIV];
        [_contentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.right.mas_equalTo(self.contentCount.mas_left).mas_equalTo(-5);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
            
        }];
    }
    return _contentIV;
}
- (UIImageView *)likeIV{
    if (!_likeIV ) {
        _likeIV = [UIImageView new];
        [_view addSubview:_likeIV];
        [_likeIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.left.mas_equalTo(10);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];
    }
    return _likeIV;
}
- (UIView *)view{
    if (!_view) {
        _view = [UIView new];
        _view.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:_view];
        [_view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(0);
            make.size.height.mas_equalTo(40);
          
            
        }];
        
        
    }
    return _view;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {

    }
    return self;
    
}



@end


//有图有真像

@implementation hasPicAndContentCell



- (UIImageView *)detailIV{
    if (!_detailIV) {
        _detailIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_detailIV];
        _detailIV.backgroundColor = [UIColor grayColor];
        [_detailIV mas_makeConstraints:^(MASConstraintMaker *make) {
          
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.size.height.mas_equalTo(540*kWindowW/670);
            make.top.mas_equalTo(_title.mas_bottom).mas_equalTo(0);
            make.bottom.mas_equalTo(self.view.mas_top).mas_equalTo(-5);
            
        }];
        
        
    }
    return _detailIV;
}

- (UILabel *)title{
    if (!_title) {
        _title = [UILabel new];
        _title.numberOfLines = 0;
        _title.font = [UIFont systemFontOfSize:15];
        _title.textColor = [UIColor blackColor];
        
        [self.contentView addSubview:_title];
        [_title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.bottom.mas_equalTo(self.detailIV.mas_top).mas_equalTo(-5);
        }];
        
    }
    return _title;
}

- (UILabel *)like{
    if (!_like) {
        _like = [UILabel new];
        _like.font = [UIFont systemFontOfSize:10];
        _like.textColor = [UIColor lightGrayColor];
        [self.view addSubview:_like];
        [_like mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 25));
            make.left.mas_equalTo(self.likeIV.mas_right).mas_equalTo(5);
         
            make.centerY.mas_equalTo(0);
            
        }];

    }
    return _like;
}

-  (UILabel *)contentCount{
    if (!_contentCount) {
        _contentCount = [UILabel new];
        _contentCount.font = [UIFont systemFontOfSize:10];
        _contentCount.textColor = [UIColor lightGrayColor];
        [self.view addSubview:_contentCount];
        [_contentCount mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 25));
            make.right.mas_equalTo(-10);
            make.centerY.mas_equalTo(0);
            
        }];
    }
    return  _contentCount;
}


- (UIImageView *)contentIV{
    if (!_contentIV ) {
        _contentIV = [UIImageView new];
        [self.view addSubview:_contentIV];
        [_contentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.right.mas_equalTo(self.contentCount.mas_left).mas_equalTo(-5);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];
    }
    return _contentIV;
}
- (UIImageView *)likeIV{
    if (!_likeIV ) {
        _likeIV = [UIImageView new];
        [self.view addSubview:_likeIV];
        [_likeIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.left.mas_equalTo(10);
            make.centerY.mas_equalTo(self.view.mas_centerY).mas_equalTo(0);
            
        }];
    }
    return _likeIV;
}
- (UIView *)view{
    if (!_view) {
        _view = [UIView new];
        _view.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:_view];
        [_view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(0);
            make.size.height.mas_equalTo(40);
            make.top.mas_equalTo(self.detailIV.mas_bottom).mas_equalTo(0);
            
        }];
        
        
    }
    return _view;
}




- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        
        
    }
    return self;
    
}

@end
