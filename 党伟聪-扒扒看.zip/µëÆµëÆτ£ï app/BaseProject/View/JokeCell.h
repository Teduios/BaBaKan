//
//  JokeCell.h
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
//有真相
@interface JokeCell : UITableViewCell

@property (nonatomic,strong) UILabel *title;
@property (nonatomic,strong) UILabel *like;
@property (nonatomic,strong) UILabel *contentCount;
@property (nonatomic,strong) UIImageView *likeIV;
@property (nonatomic,strong) UIImageView *contentIV;
@property (nonatomic,strong) UIView *view;



@end
//纯图片
@interface hasPicCell : UITableViewCell

@property (nonatomic,strong) UIImageView *detailIV;
@property (nonatomic,strong) UILabel *like;
@property (nonatomic,strong) UILabel *contentCount;
@property (nonatomic,strong) UIImageView *likeIV;
@property (nonatomic,strong) UIImageView *contentIV;
@property (nonatomic,strong) UIView *view;
@end
//有图有真相
@interface hasPicAndContentCell : UITableViewCell
@property (nonatomic,strong) UIImageView *detailIV;
@property (nonatomic,strong) UILabel *title;
@property (nonatomic,strong) UILabel *like;
@property (nonatomic,strong) UILabel *contentCount;
@property (nonatomic,strong) UIImageView *likeIV;
@property (nonatomic,strong) UIImageView *contentIV;
@property (nonatomic,strong) UIView *view;

@end