//
//  ReadCell.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ReadCell.h"

@implementation ReadCell


-(UIImageView *)iconIV{
    if (!_iconIV) {
        _iconIV = [UIImageView new];
        [self.contentView addSubview:_iconIV];
        
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(80, 50));

        }];
        
    }
    return _iconIV;
}

-(UILabel *)title{
    if (!_title) {
        _title = [UILabel new];
        [self.contentView addSubview:_title];
        
        _title.textColor = [UIColor blackColor];
        _title.font = [UIFont systemFontOfSize:15];
        _title.numberOfLines = 0;
        
        
        [_title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(5);
            make.right.mas_equalTo(-5);
            make.top.mas_equalTo(10);
            
        }];
        
    }
    return _title;
}

- (UILabel *)timetip{
    if (!_timetip) {
        _timetip = [UILabel new];
        [self.contentView addSubview:_timetip];
        _timetip.font = [UIFont systemFontOfSize:10];
        _timetip.textColor = [UIColor lightGrayColor];
        _timetip.numberOfLines = 0;
        [_timetip mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.title);
            make.bottom.mas_equalTo(-5);
            make.size.mas_equalTo(CGSizeMake(60, 10));
        }];
    }
    return _timetip;
}


- (UILabel *)comments{
    if (!_comments) {
        _comments = [UILabel new];
    
        [self.contentView addSubview:_comments];
         _comments.font = [UIFont systemFontOfSize:10];
        _comments.textAlignment = NSTextAlignmentRight;
        _comments.textColor = [UIColor lightGrayColor];
        [_comments mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.iconIV2.mas_left).mas_equalTo(-3);
            make.centerY.mas_equalTo(self.iconIV2.mas_centerY).mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(20, 10));
        }];
        
    }
    return _comments;
}

-(UIImageView *)iconIV2{
    if (!_iconIV2) {
        _iconIV2 = [UIImageView new];
        [self.contentView addSubview:_iconIV2];
        
        [_iconIV2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-5);
            make.bottom.mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(17, 13));
            
        }];
        
    }
    return _iconIV2;
}


- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
}

@end


@implementation ReadCell2

-(UILabel *)title{
    if (!_title) {
        _title = [UILabel new];
        [self.contentView addSubview:_title];
        _title.backgroundColor = kRGBColor(38, 31, 25);
        _title.textColor = [UIColor whiteColor];
        [_title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.bottom.mas_equalTo(0);
            make.size.height.mas_equalTo(40);
            make.top.mas_equalTo(self.iconIV.mas_bottom).mas_equalTo(0);
        }];
        
    }
    return _title;
}

-(UIImageView *)iconIV{
    if (!_iconIV) {
        _iconIV = [UIImageView new];
        [self.contentView addSubview:_iconIV];
        
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(0);
            make.bottom.mas_equalTo(-40);
            make.size.height.mas_equalTo(150);
            
        }];
        
    }
    return _iconIV;
}


@end
