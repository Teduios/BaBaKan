//
//  SmallCell.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SmallCell.h"

@implementation SmallCell

- (UIImageView *)BigimageView{
    if (!_BigimageView) {
        _BigimageView = [UIImageView new];
    
        
    }
    return _BigimageView;
}

- (UILabel *)titlelb{
    if (!_titlelb) {
        _titlelb = [UILabel new];
            }
    return _titlelb;
    
}

- (UILabel *)visitlb{
    
    if (!_visitlb) {
        _visitlb = [UILabel new];
          }
    return _visitlb;
}
- (UIImageView *)SmallimageView{
    if (!_SmallimageView) {
        _SmallimageView = [[UIImageView alloc]init];
                
    }
    return _SmallimageView;
}

@end
