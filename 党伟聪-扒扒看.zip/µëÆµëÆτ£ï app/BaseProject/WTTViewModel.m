//
//  WTTViewModel.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTViewModel.h"

@implementation WTTViewModel


- (instancetype)initWithType:(WTTType)type{
    if (self = [self init]) {
        _type = type;
    }
    return self;
}



- (NSInteger)rowNumber{
    return self.dataArr.count;
}


//把数组中的对象对应到Model中
- (WTTDataListModel *)WTTDataListModeForRow:(NSInteger)row{
    return self.dataArr[row];
}
//获取图片
- (NSURL *)imsrcURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self WTTDataListModeForRow:row].img_src];
}
//获取标题
- (NSString *)titleForRow:(NSInteger)row{
    return [self WTTDataListModeForRow:row].title;
    
}
/*获取评论数*/
- (double)visitNumForRow:(NSInteger)row{
    return [self WTTDataListModeForRow:row].visit_num;
}

//获取详情页的网址内容所需要的Id值
- (NSString *)IdForRow:(NSInteger)row{
    return [self WTTDataListModeForRow:row].Id;
}
//获取详情页的网址内容所需要的ack_code值
- (NSString *)ackForRow:(NSInteger)row{
    return [self WTTDataListModeForRow:row].ack_code;
}

//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    
    [WTTNetManager getWTTType:_type pubtime:_pubtime creatSign:_creatSign completionHanle:^(WTTModel *model, NSError *error) {
        
        if ([_pubtime isEqualToString:@"0"]) {
            [self.dataArr removeAllObjects];
        }
        
        _nextSign = model.data.nextsign;
        _nextTime = [NSString stringWithFormat:@"%.0ld",(long)model.data.nexttime];
        
        [self.dataArr addObjectsFromArray:model.data.list];
        completionHandle(error);
        
        
      
    }];
    
    
    
}
//刷新

- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    
    _pubtime = @"0";
    _creatSign = nil;
  
    [self getDataFromNetCompleteHandle:completionHandle];
   }

//加载更多
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{

    _pubtime = _nextTime;
    _creatSign = _nextSign;

    [self getDataFromNetCompleteHandle:completionHandle];
}





@end
