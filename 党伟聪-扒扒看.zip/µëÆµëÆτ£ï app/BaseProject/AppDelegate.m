//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"


#import "RESideMenu.h"

#import "WTTBarController.h"



#import "MobClick.h"
#import "UMSocial.h"
#import "UMSocialQQHandler.h"

#import "LoginViewController.h"
#import "WelcomeViewController.h"

#import "ResideViewController.h"
#import "JokeViewController.h"




@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];

    self.window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    
    NSString *key = @"CFBundleShortVersionString";
    NSDictionary *info = [[NSBundle mainBundle]infoDictionary];
    NSString *currentVersion = info[key];
    NSString *runVersion = [[NSUserDefaults standardUserDefaults] stringForKey:key];
    if (runVersion == nil || ![runVersion isEqualToString:currentVersion]) {
        
        self.window.rootViewController = [WelcomeViewController new];
        
        [[NSUserDefaults standardUserDefaults]setValue:currentVersion forKey:key];
        
    }else{
        
         self.window.rootViewController = self.sideMenu;

    }
    



    [self configGlobalUIStyle];
    
    
    
    

[self.window makeKeyAndVisible];
    
    
    /**
     * 测试代码
     */
    
//    self.window.rootViewController = [WelcomeViewController new];
//    [self.window makeKeyAndVisible];
    
    /**
     *  友盟统计
     */
    
    [MobClick startWithAppkey:appleKey reportPolicy:BATCH channelId:nil];
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary]objectForKey:@"CFBundleShortVersionString"];
    [MobClick setAppVersion:version];
    
    
    
    /**
     *  友盟第三方登录
     */
    
    [UMSocialQQHandler setQQWithAppId:@"1104539912" appKey:@"eFVgRits2fqf36Jf" url:@"http://www.umeng.com/social"];
    
    
    [UMSocialData setAppKey:appleKey];
    
    
    
    
    return YES;

}



-(void)configGlobalUIStyle{
    /**
     *  导航栏不透明
     */
    [[UINavigationBar appearance] setTranslucent:NO];
    /**
     *  设置导航栏的背景图
     */

    
    
    /**
     *  配置导航栏的题目
     */
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20],NSForegroundColorAttributeName:[UIColor whiteColor]}];
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"导航栏蒙版"] forBarMetrics:UIBarMetricsDefault];
}

- (RESideMenu *)sideMenu{
    if (!_sideMenu) {
        //从故事板中获取控制器
        LoginViewController *vc = kVCFromSb(@"LoginViewController", @"Main");
        _sideMenu = [[RESideMenu alloc] initWithContentViewController:[WTTBarController new] leftMenuViewController:vc rightMenuViewController:nil];
        //缩放比例
        _sideMenu.contentViewScaleValue = 0.5                                                       ;
 
        
    }
    return _sideMenu;
}

-(BOOL)application:(UIApplication *)application openURL:(nonnull NSURL *)url sourceApplication:(nullable NSString *)sourceApplication annotation:(nonnull id)annotation{
    BOOL result = [UMSocialSnsService handleOpenURL:url];
    if (result == FALSE) {
        
    }
    return result;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return  [UMSocialSnsService handleOpenURL:url];
}

@end
