//
//  VideoNetManager.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoNetManager.h"

@implementation VideoNetManager

+(id)getVideoWithIndex:(NSInteger)index completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://c.m.163.com/nc/video/home/%ld-10.html",(long)index];
     //将网络数据解析到本地的Model
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([VideoModel objectWithKeyValues:responseObj],error);
    }];
}


@end
