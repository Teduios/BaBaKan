//
//  JokeNetManager.m
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "JokeNetManager.h"


@implementation JokeNetManager

+(id)getAddPage:(NSInteger)page completionHanle:(void (^)(id, NSError *))completionHandle{
    
    NSString *path = [NSString stringWithFormat:@"http://api.3g.ifeng.com/clientShortNews?type=joke&page=%ld&gv=4.4.8&av=4.4.8&uid=99000536549346&deviceid=99000536549346&proid=ifengnews&os=android_19&df=androidphone&vt=5&screen=720x1280&publishid=6001",(long)page];
    //将网络数据解析到本地的Model
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([KidModel objectWithKeyValues:responseObj],error);
        
    }];
    
    
}

@end
