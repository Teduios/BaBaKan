//
//  WTTNetManager.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTNetManager.h"

@implementation WTTNetManager

+(id)getWTTType:(WTTType)type pubtime:(NSString *)pubtime creatSign:(NSString *)creatSign completionHanle:(void (^)(id, NSError *))completionHandle{
    //根据不同的类型 设置对应的请求地址
    NSString *path = nil;
    switch (type) {
        case WTTTypeReMen: {
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/hot?pubtime=%@&cate_sign=%@",pubtime,creatSign];
            break;
        }
        case WTTTypeMeiNv: {
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/list?pubtime=%@&cate_list=5&cate_sign=%@&cate_type=cate",pubtime,creatSign];
            
            break;
        }
        case WTTTypeHuDong: {
            
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/list?pubtime=%@&cate_list=33&cate_sign=%@&cate_type=cate",pubtime,creatSign];
            
            break;
        }
        case WTTTypeMengCong: {
            
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/list?pubtime=%@&cate_list=34&cate_sign=%@&cate_type=cate",pubtime,creatSign];
            break;
        }
        case WTTTypeQiqu: {
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/list?pubtime=%@&cate_list=31&cate_sign=%@&cate_type=cate",pubtime,creatSign];
            
            break;
        }
        case WTTTypeBaoXiao: {
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/list?pubtime=%@&cate_list=3&cate_sign=%@&cate_type=cate",pubtime,creatSign];
            
            
            break;
        }
        case WTTTypeShiPin: {
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/list?pubtime=%@&cate_list=36&cate_sign=%@&cate_type=cate",pubtime,creatSign];
            break;
        }
        case WTTTypeShengHuo: {
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/list?pubtime=%@&cate_list=35&cate_sign=%@&cate_type=cate",pubtime,creatSign];
            break;
        }
        case WTTTypeZiXun: {
            path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/list?pubtime=%@&cate_list=32&cate_sign=%@&cate_type=cate",pubtime,creatSign];
            
            NSLog(@"%lu",(unsigned long)type);
            break;
        }
        default: {
            break;
        }
            
            
    }
    
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([WTTModel objectWithKeyValues:responseObj],error);
    }];
    
}


+(id)getPHType:(PHType)type2 completionHanle:(void (^)(id, NSError *))conpletionHandle{
    NSString *path = nil;
    switch (type2) {
        case PHTypeCuanHong: {
            path = @"http://app.lerays.com/api/stream/rank/trending";
            break;
        }
        case PHTypeZhouBang: {
            path = @"http://app.lerays.com/api/stream/rank/week";
            break;
        }
        case PHTypeYueBang: {
            path = @"http://app.lerays.com/api/stream/rank/month";
            break;
        }
        case PHTypeShenHuiFu: {
            path = @"http://app.lerays.com/api/stream/rank/quickreply";
            break;
        }
        default: {
            break;
        }
    }
    
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
        conpletionHandle([WTTModel objectWithKeyValues:responseObj],error);
        
    }];
}



@end
