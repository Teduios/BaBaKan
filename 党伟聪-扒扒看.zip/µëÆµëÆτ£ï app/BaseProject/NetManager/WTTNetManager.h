//
//  WTTNetManager.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "WTTModel.h"

typedef NS_ENUM(NSUInteger, WTTType) {
    WTTTypeReMen,//热门
    WTTTypeMeiNv,//美女
    WTTTypeHuDong,//互动
    WTTTypeMengCong,//萌宠
    WTTTypeQiqu,//奇趣
    WTTTypeBaoXiao,//爆笑
    WTTTypeShiPin,//视频
    WTTTypeShengHuo,//生活
    WTTTypeZiXun,//资讯
};

typedef NS_ENUM(NSUInteger,PHType) {
    PHTypeCuanHong,//蹿红
    PHTypeZhouBang,//周榜
    PHTypeYueBang,//月榜
    PHTypeShenHuiFu,//神回复
    
};


@interface WTTNetManager : BaseNetManager

+ (id)getWTTType:(WTTType)type pubtime:(NSString *)pubtime creatSign:(NSString *)creatSign completionHanle:(void(^)(id model,NSError *error))completionHandle;

+(id)getPHType:(PHType)type completionHanle:(void(^)(id model,NSError *error))conpletionHandle;


@end
