//
//  JokeNetManager.h
//  BaseProject
//
//  Created by apple-jd19 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "KidModel.h"


@interface JokeNetManager : BaseNetManager

+ (id)getAddPage:(NSInteger) page completionHanle : (void(^)(id model,NSError *error))completionHandle;



@end
