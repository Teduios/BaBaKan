//
//  ReadNetManager.h
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "ReadModel.h"

@interface ReadNetManager : BaseNetManager

+ (id)getReadWithPage:(NSInteger)page completionHandle:(void(^)(id model,NSError *error))completionHandle;

@end
