//
//  ReadNetManager.m
//  BaseProject
//
//  Created by apple-jd19 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ReadNetManager.h"

@implementation ReadNetManager

+(id)getReadWithPage:(NSInteger)page completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://api.iclient.ifeng.com/ClientNews?id=DS57,FOCUSDS57&page=%ld&gv=4.4.8&av=4.4.8&uid=99000536549346&deviceid=99000536549346&proid=ifengnews&os=android_19&df=androidphone&vt=5&screen=720x1280&publishid=6001",(long)page];
     //将网络数据解析到本地的Model
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
        
        completionHandle([ReadModel objectArrayWithKeyValuesArray:responseObj].firstObject,error);
        
    }];
    
}

@end
